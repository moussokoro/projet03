<!DOCTYPE html>
<html>
    <head>
        <title>menu</title>
        <meta charset="utf-8"/>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <script src="js/jquery.min.js"></script>
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <script src="js/bootstrap.min.js"></script>
        <link href='http://fonts.googleapis.com/css?family=Holtwood+One+SC' rel='stylesheet' type='text/css'>
        <link rel="stylesheet" href="css/styles.css">
        <link rel="stylesheet" type="text/css" href="css/all.min.css">
        <link rel="stylesheet" type="text/css" href="js/all.min.js">
    </head>
    
    
    <body>
        <div class="container site">
            <h1 class="text-logo"><span class="fas fa-cutlery"></span> Bienvenue chez citydia <span class="fas fa-market"></span></h1>
            <nav><ul class="nav nav-pills">
                            <li role="presentation" class="active">
                                <a href="#1" data-toggle="tab">MENU</a></li>
                                 </ul>
                    </nav>
                    <div class="tab-content"><div class="tab-pane active" id="1"><div class="row"><div class="col-sm-6 col-md-4">
                                <div class="thumbnail">
                                    <img src="image/m1.png" alt="...">
                                    <div class="price">8.90 €</div>
                                    <div class="caption">
                                        <h4>Menu Classic</h4>
                                        <p>Sandwich: Burger, Salade, Tomate, Cornichon + Frites + Boisson</p>
                                        <a href="#" class="btn btn-order" role="button"><span class="fas fa-shopping-cart"></span> Commander</a>
                                    </div>
                                </div>
                            </div><div class="col-sm-6 col-md-4">
                                <div class="thumbnail">
                                    <img src="image/m2.png" alt="...">
                                    <div class="price">9.50 €</div>
                                    <div class="caption">
                                        <h4>Menu Bacon</h4>
                                        <p>Sandwich: Burger, Fromage, Bacon, Salade, Tomate + Frites + Boisson</p>
                                        <a href="#" class="btn btn-order" role="button"><span class="fas fa-shopping-cart"></span> Commander</a>
                                    </div>
                                </div>
                            </div><div class="col-sm-6 col-md-4">
                                <div class="thumbnail">
                                    <img src="image/m3.png" alt="...">
                                    <div class="price">10.90 €</div>
                                    <div class="caption">
                                        <h4>Menu Big</h4>
                                        <p>Sandwich: Double Burger, Fromage, Cornichon, Salade + Frites + Boisson</p>
                                        <a href="#" class="btn btn-order" role="button"><span class="fas fa-shopping-cart"></span> Commander</a>
                                    </div>
                                </div>
                            </div><div class="col-sm-6 col-md-4">
                                <div class="thumbnail">
                                    <img src="image/m4.png" alt="...">
                                    <div class="price">9.90 €</div>
                                    <div class="caption">
                                        <h4>Menu Chicken</h4>
                                        <p>Sandwich: Poulet Frit, Tomate, Salade, Mayonnaise + Frites + Boisson</p>
                                        <a href="#" class="btn btn-order" role="button"><span class="fas fa-shopping-cart"></span> Commander</a>
                                    </div>
                                </div>
                            </div><div class="col-sm-6 col-md-4">
                                <div class="thumbnail">
                                    <img src="image/m5.png" alt="...">
                                    <div class="price">10.90 €</div>
                                    <div class="caption">
                                        <h4>Menu Fish</h4>
                                        <p>Sandwich: Poisson, Salade, Mayonnaise, Cornichon + Frites + Boisson</p>
                                        <a href="#" class="btn btn-order" role="button"><span class="fas fa-shopping-cart"></span> Commander</a>
                                    </div>
                                </div>
                            </div><div class="col-sm-6 col-md-4">
                                <div class="thumbnail">
                                    <img src="image/m6.png" alt="...">
                                    <div class="price">11.90 €</div>
                                    <div class="caption">
                                        <h4>Menu Double Steak</h4>
                                        <p>Sandwich: Double Burger, Fromage, Bacon, Salade, Tomate + Frites + Boisson</p>
                                        <a href="#" class="btn btn-order" role="button"><span class="fas fa-shopping-cart"></span> Commander</a>
                                    </div>
                                </div>
                            </div></div>
                        </div>