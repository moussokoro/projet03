 <!DOCTYPE html>
<html>
<head>
	<title>fruit</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="js/bootstrap.min.js">
	<link rel="stylesheet" type="text/css" href="styl.css">
	<link rel="stylesheet" type="text/css" href="js/all.min.js">
	<link rel="stylesheet" type="text/css" href="css/all.min.css">
	
</head>
<body>
	<h1 style="text-align: center;font-size: 50px; color: orange"><i class="fas fa-shopping-cart">BIENVENUE CHEZ CITYDIA</i><i class="fas fa-shopping-cart"></i></h1>
	<div class="content">
		<div class="wrapper">
	<div class="bg">
		<h1 style="text-align: center; padding: 50px;font-family:Broadway; "><span>FRUITS</span></h1>
		<h5 class="brz-tp-heading5" style="text-align: center;padding: 50px;"><span class="brz-cp-color1">MOUSSE À LA MENTHE À LA FRAISE ………………………………………..$2.95</span></h5>
		<p style="color: gray;text-align: center;">Homemade buttermilk biscuits, sweet potato biscuits and cornbread. Served with<br> homemade peach-pepper jelly and apple butter</p>
      <div class="mass" class="circle">
		<img style="border-radius:-100px;"  src="image/fruit1.jpg " alt="" class="img-circle">
	<h5 class="brz-tp-heading5" style="text-align: center;padding: 50px;"><span class="brz-cp-color1">PANACOTTA ITALIEN ………………………………………..$2.95</span></h5>
		<p style="color: gray;text-align: center;">Homemade buttermilk biscuits, sweet potato biscuits and cornbread. Served with<br> homemade peach-pepper jelly and apple butter</p>
      <div class="mass" class="">
		<img style="border-radius:-100px;"  src="image/fruit5.jpg " alt="" >
		<h5 class="brz-tp-heading5" style="text-align: center;padding: 50px;"><span class="brz-cp-color1">SALADE DE PANIER DE BAIES SAUVAGES …………………,…………………..$6.95</span></h5>
		<p style="color: gray;text-align: center;">Biscuits crémeux au babeurre, biscuits à la patate<br>douce et pain de maïs. Servi avec gelée de poivron et<br> de pêche fait maison et beurre de pomme</p>
      <div class="mass" class="circle">
		<img style="border-radius:-100px;"  src="image/fruit3.jpg " alt="" >
		<h1 style="text-align: center; padding: 50px;font-family:Broadway; "><span>CAKES</span></h1>
		<h5 class="brz-tp-heading5" style="text-align: center;padding: 50px;"><span class="brz-cp-color1">GATEAU CREMEUX ………………………………………..$2.95</span></h5>
		<p style="color: gray;text-align: center;">Homemade buttermilk biscuits, sweet potato biscuits and cornbread. Served with<br> homemade peach-pepper jelly and apple butter</p>
      <div class="mass" class="circle">
      	<img style="border-radius:-100px; height: 90px;"  src="image/l2.jpg " alt="" >
	<h5 class="brz-tp-heading5" style="text-align: center;padding: 50px;"><span class="brz-cp-color1">Gâteau aux noisettes ………………………………………..$2.95</span></h5>
		<p style="color: gray;text-align: center;">Homemade buttermilk biscuits, sweet potato biscuits and cornbread. Served with<br> homemade peach-pepper jelly and apple butter</p>
      <div class="mass" class="circle">
		<img style="border-radius:-100px;"  src="image/fruit5.jpg " alt="" >
		<h5 class="brz-tp-heading5" style="text-align: center;padding: 50px;"><span class="brz-cp-color1">GÂTEAU À LA CRÈME ET AU CHOCOLAT WHIPPED ………………………………………..$2.95</span></h5>
		<p style="color: gray;text-align: center;">Homemade buttermilk biscuits, sweet potato biscuits and cornbread. Served with<br> homemade peach-pepper jelly and apple butter</p>
      <img src="image/fruit6.jpg">
<h5 class="brz-tp-heading5" style="text-align: center;padding: 50px;"><span class="brz-cp-color1">Fondant au chocolat ………………………………………..$4.90</span></h5>
		<p style="color: gray;text-align: center;">Au choix: Chocolat Blanc ou au lait</p>
      <div class="mass" class="circle">
		<img style="border-radius:-100px; height: 160px;"  src="image/d1.png " alt="" >
	
		<h5 class="brz-tp-heading5" style="text-align: center;padding: 50px;"><span class="brz-cp-color1">Muffin ………………………………………..$2.95</span></h5>
		<p style="color: gray;text-align: center;">Au choix: Au fruits ou au chocolat</p>
      <div class="mass" class="thumbnail">
		<img style="border-radius:-100px; height: 100px;"  src="image/d2.png " alt="" >
		<h5 class="brz-tp-heading5" style="text-align: center;padding: 50px;"><span class="brz-cp-color1">Beignet………………………………………..$1.90</span></h5>
		<p style="color: gray;text-align: center;">Au choix: Au chocolat ou à la vanille</p>
      <div class="mass" class="circle">
		<img style="border-radius:100px; height: 80px;"  src="image/d3.png " alt="" >
		<h5 class="brz-tp-heading5" style="text-align: center;padding: 50px;"><span class="brz-cp-color1">Sundae ………………………………………..$2.95</span></h5>
		<p style="color: gray;text-align: center;">Au choix: Fraise, Caramel ou Chocolat</p>
      <div class="mass" class="circle">
		<img style="border-radius:-100px; height: 80px;"  src="image/d5.png " alt="" >
		</div>

</div>
</body>
</html>