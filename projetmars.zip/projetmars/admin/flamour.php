<!DOCTYPE html>
<html>
<head>
	<title>gallery</title>
</head>
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="js/bootstrap.min.js">
<link rel="stylesheet" type="text/css" href="slyl.css">
<body>
	
	<div class="all">
		<span class="brz-cp-color3">CHECK OUT OUR</span><br></div>
		<div class="all1">
		<span class="brz-cp-color2">Image Gallery</span>
	</div>
	<section id="super">
      <div class="col-md-3 col-sm-6 feature text-center">
          <div class="overlay">
            <img src="image/l6.jpg" alt="" class="img-responsive">
            <div class="overlay-shadow">

            </div>
          </div>
          
          <h4><strong>JANBON</strong></h4>

      	
          
        </div>
        <div class="col-md-3 col-sm-6 feature text-center">
          <div class="overlay">
            <img src="image/l3.jpg" alt="" class="img-responsive">
            <div class="overlay-shadow">
              <div class="overlay-content">
                
              </div>
            </div>
          </div>
          <h4><strong>Our Services</strong></h4>

      	
         
        </div>
        <div class="col-md-3 col-sm-6 feature text-center">
          <div class="overlay">
            <img src="image/l4.jpg" alt="" class="img-responsive">
            <div class="overlay-shadow">
              <div class="overlay-content">
                
              </div>
            </div>
          </div>
          <h4><strong>BUST DESSERTS</strong></h4>

      	
          
        </div>
        <div class="col-md-3 col-sm-6 feature text-center">
          <div class="overlay">
            <img src="image/l5.jpg" alt="" class="img-responsive">
            <div class="overlay-shadow">
              <div class="overlay-content">
                
              </div>
            </div>
          </div>
          <h4><strong>SANDWICH MENU</strong></h4>

      	
          
        </div>
        <div class="col-md-3 col-sm-6 feature text-center">
          <div class="overlay">
            <img src="image/slide1.jpg" alt="" class="img-responsive">
            <div class="overlay-shadow">
              <div class="overlay-content">
                
              </div>
            </div>
          </div>
          <h4><strong>Soupe fraîche de concombre</strong></h4>

      	
          
        </div>
        <div class="col-md-3 col-sm-6 feature text-center">
          <div class="overlay">
            <img src="image/l6.jpg" alt="" class="img-responsive">
            <div class="overlay-shadow">
              <div class="overlay-content">
                
              </div>
            </div>
          </div>
          <h4><strong>Cochon de lait rôti</strong></h4>

      	
         
        </div>
        <div class="col-md-3 col-sm-6 feature text-center">
          <div class="overlay">
            <img src="image/21.jpg" alt="" class="img-responsive">
            <div class="overlay-shadow">
              <div class="overlay-content">
                
              </div>
            </div>
          </div>
          <h4><strong>Salade de fruits frais</strong></h4>

      	
          
        </div>
        <div class="col-md-3 col-sm-6 feature text-center">
          <div class="overlay">
            <img src="image/sa6.png" alt="" class="img-responsive">
            <div class="overlay-shadow">
              <div class="overlay-content">
                
              </div>
            </div>
          </div>
          <h4><strong>Our Services</strong></h4>

      	
          
        </div>
        <div class="col-md-3 col-sm-6 feature text-center">
          <div class="overlay">
            <img src="image/l2.jpg" alt="" class="img-responsive">
            <div class="overlay-shadow">
              <div class="overlay-content">
                
              </div>
            </div>
          </div>
          <h4><strong>BONBON BEIGNET</strong></h4>

          
        </div>
        
        <div class="col-md-3 col-sm-6 feature text-center">
          <div class="overlay">
            <img src="image/l3.jpg" alt="" class="img-responsive">
            <div class="overlay-shadow">
              <div class="overlay-content">
                 
              </div>
            </div>
          </div>
          <h4 style="color: red"><strong>LEGUME AU SOUP</strong></h4>
          
        </div>
        <div class="col-md-3 col-sm-6 feature text-center">
          <div class="overlay">
            <img src="image/f3.jpg" alt="" class="img-responsive">
            <div class="overlay-shadow">
              <div class="overlay-content">
              	
            </div>
          </div>
          <h4><strong>MENU POUR CARTE</strong></h4>
          
        </div>	
        </section>
        

</body>
</html>