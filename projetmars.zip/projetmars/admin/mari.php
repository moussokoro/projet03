<!DOCTYPE html>
<html>
    <head>
        <title>Burger Code</title>
        <meta charset="utf-8"/>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <script src="js/jquery.min.js"></script>
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <script src="js/bootstrap.min.js"></script>
        <link href='http://fonts.googleapis.com/css?family=Holtwood+One+SC' rel='stylesheet' type='text/css'>
        <link rel="stylesheet" href="css/styles.css">
        <link rel="stylesheet" type="text/css" href="css/all.min.css">
        <link rel="stylesheet" type="text/css" href="js/all.min.js">
    </head>
    
    
    <body>
        <div class="container site">
            <h1 class="text-logo"><span class="fas fa-cutlery"></span> Bienvenue chez citydia <span class="fas fa-market"></span></h1>
            <nav><ul class="nav nav-pills">
                            <li role="presentation" class="active">
                                <a href="#1" data-toggle="tab">fruits</a></li>
                                <li role="presentation"><a href="#2" data-toggle="tab">Burgers</a></li><li role="presentation"><a href="#3" data-toggle="tab">Snacks</a></li><li role="presentation"><a href="#4" data-toggle="tab">Salades et vegetation</a></li><li role="presentation"><a href="#5" data-toggle="tab">Boissons</a></li><li role="presentation"><a href="#6" data-toggle="tab">Desserts</a></li>
                                <li role="presentation" >
                            
                            </ul>
                    </nav><div class="tab-content"><div class="tab-pane active" id="1"><div class="row"><div class="col-sm-6 col-md-4">
                                <div class="thumbnail">
                                    <img src="image/m1.png" alt="...">
                                    <div class="price">8.90 €</div>
                                    <div class="caption">
                                        <h4>Menu Classic</h4>
                                        <p>Sandwich: Burger, Salade, Tomate, Cornichon + Frites + Boisson</p>
                                        <a href="#" class="btn btn-order" role="button"><span class="fas fa-shopping-cart"></span> Commander</a>
                                    </div>
                                </div>
                            </div><div class="col-sm-6 col-md-4">
                                <div class="thumbnail">
                                    <img src="image/m2.png" alt="...">
                                    <div class="price">9.50 €</div>
                                    <div class="caption">
                                        <h4>Menu Bacon</h4>
                                        <p>Sandwich: Burger, Fromage, Bacon, Salade, Tomate + Frites + Boisson</p>
                                        <a href="#" class="btn btn-order" role="button"><span class="fas fa-shopping-cart"></span> Commander</a>
                                    </div>
                                </div>
                            </div><div class="col-sm-6 col-md-4">
                                <div class="thumbnail">
                                    <img src="image/m3.png" alt="...">
                                    <div class="price">10.90 €</div>
                                    <div class="caption">
                                        <h4>Menu Big</h4>
                                        <p>Sandwich: Double Burger, Fromage, Cornichon, Salade + Frites + Boisson</p>
                                        <a href="#" class="btn btn-order" role="button"><span class="fas fa-shopping-cart"></span> Commander</a>
                                    </div>
                                </div>
                            </div><div class="col-sm-6 col-md-4">
                                <div class="thumbnail">
                                    <img src="image/m4.png" alt="...">
                                    <div class="price">9.90 €</div>
                                    <div class="caption">
                                        <h4>Menu Chicken</h4>
                                        <p>Sandwich: Poulet Frit, Tomate, Salade, Mayonnaise + Frites + Boisson</p>
                                        <a href="#" class="btn btn-order" role="button"><span class="fas fa-shopping-cart"></span> Commander</a>
                                    </div>
                                </div>
                            </div><div class="col-sm-6 col-md-4">
                                <div class="thumbnail">
                                    <img src="image/m5.png" alt="...">
                                    <div class="price">10.90 €</div>
                                    <div class="caption">
                                        <h4>Menu Fish</h4>
                                        <p>Sandwich: Poisson, Salade, Mayonnaise, Cornichon + Frites + Boisson</p>
                                        <a href="#" class="btn btn-order" role="button"><span class="fas fa-shopping-cart"></span> Commander</a>
                                    </div>
                                </div>
                            </div><div class="col-sm-6 col-md-4">
                                <div class="thumbnail">
                                    <img src="image/m6.png" alt="...">
                                    <div class="price">11.90 €</div>
                                    <div class="caption">
                                        <h4>Menu Double Steak</h4>
                                        <p>Sandwich: Double Burger, Fromage, Bacon, Salade, Tomate + Frites + Boisson</p>
                                        <a href="#" class="btn btn-order" role="button"><span class="fas fa-shopping-cart"></span> Commander</a>
                                    </div>
                                </div>
                            </div></div>
                        </div><div class="tab-pane" id="2"><div class="row"><div class="col-sm-6 col-md-4">
                                <div class="thumbnail">
                                    <img src="image/b1.png" alt="...">
                                    <div class="price">5.90 €</div>
                                    <div class="caption">
                                        <h4>Classic</h4>
                                        <p>Sandwich: Burger, Salade, Tomate, Cornichon</p>
                                        <a href="#" class="btn btn-order" role="button"><span class="fas fa-shopping-cart"></span> Commander</a>
                                    </div>
                                </div>
                            </div><div class="col-sm-6 col-md-4">
                                <div class="thumbnail">
                                    <img src="image/sa3.png" alt="...">
                                    <div class="price">5.90 €</div>
                                    <div class="caption">
                                        <h4>Salade Light</h4>
                                        <p>Salade, Tomate, Concombre, Maïs et Vinaigre balsamique</p>
                                        <a href="#" class="btn btn-order" role="button"><span class="fas fa-shopping-cart"></span> Commander</a>
                                    </div>
                                </div>
                            </div><div class="col-sm-6 col-md-4">
                                <div class="thumbnail">
                                    <img src="image/sa3.png" alt="...">
                                    <div class="price">5.90 €</div>
                                    <div class="caption">
                                        <h4>Salade Light</h4>
                                        <p>Salade, Tomate, Concombre, Maïs et Vinaigre balsamique</p>
                                        <a href="#" class="btn btn-order" role="button"><span class="fas fa-shopping-cart"></span> Commander</a>
                                    </div>
                                </div>
                            </div><div class="col-sm-6 col-md-4">
                                <div class="thumbnail">
                                    <img src="image/sa3.png" alt="...">
                                    <div class="price">5.90 €</div>
                                    <div class="caption">
                                        <h4>Salade Light</h4>
                                        <p>Salade, Tomate, Concombre, Maïs et Vinaigre balsamique</p>
                                        <a href="#" class="btn btn-order" role="button"><span class="fas fa-shopping-cart"></span> Commander</a>
                                    </div>
                                </div>
                            </div><div class="col-sm-6 col-md-4">
                                <div class="thumbnail">
                                    <img src="image/b2.png" alt="...">
                                    <div class="price">6.50 €</div>
                                    <div class="caption">
                                        <h4>Bacon</h4>
                                        <p>Sandwich: Burger, Fromage, Bacon, Salade, Tomate</p>
                                        <a href="#" class="btn btn-order" role="button"><span class="fas fa-shopping-cart"></span> Commander</a>
                                    </div>
                                </div>
                            </div><div class="col-sm-6 col-md-4">
                                <div class="thumbnail">
                                    <img src="image/b3.png" alt="...">
                                    <div class="price">6.90 €</div>
                                    <div class="caption">
                                        <h4>Big</h4>
                                        <p>Sandwich: Double Burger, Fromage, Cornichon, Salade</p>
                                        <a href="#" class="btn btn-order" role="button"><span class="fas fa-shopping-cart"></span> Commander</a>
                                    </div>
                                </div>
                            </div><div class="col-sm-6 col-md-4">
                                <div class="thumbnail">
                                    <img src="image/b4.png" alt="...">
                                    <div class="price">5.90 €</div>
                                    <div class="caption">
                                        <h4>Chicken</h4>
                                        <p>Sandwich: Poulet Frit, Tomate, Salade, Mayonnaise</p>
                                        <a href="#" class="btn btn-order" role="button"><span class="fas fa-shopping-cart"></span> Commander</a>
                                    </div>
                                </div>
                            </div><div class="col-sm-6 col-md-4">
                                <div class="thumbnail">
                                    <img src="image/b5.png" alt="...">
                                    <div class="price">6.50 €</div>
                                    <div class="caption">
                                        <h4>Fish</h4>
                                        <p>Sandwich: Poisson Pané, Salade, Mayonnaise, Cornichon</p>
                                        <a href="#" class="btn btn-order" role="button"><span class="fas fa-shopping-cart"></span> Commander</a>
                                    </div>
                                </div>
                            </div><div class="col-sm-6 col-md-4">
                                <div class="thumbnail">
                                    <img src="image/b6.png" alt="...">
                                    <div class="price">7.50 €</div>
                                    <div class="caption">
                                        <h4>Double Steak</h4>
                                        <p>Sandwich: Double Burger, Fromage, Bacon, Salade, Tomate</p>
                                        <a href="#" class="btn btn-order" role="button"><span class="fas fa-shopping-cart"></span> Commander</a>
                                    </div>
                                </div>
                            </div></div>
                        </div><div class="tab-pane" id="3"><div class="row"><div class="col-sm-6 col-md-4">
                                <div class="thumbnail">
                                    <img src="image/s1.png" alt="...">
                                    <div class="price">3.90 €</div>
                                    <div class="caption">
                                        <h4>Frites</h4>
                                        <p>Pommes de terre frites</p>
                                        <a href="#" class="btn btn-order" role="button"><span class="fas fa-shopping-cart"></span> Commander</a>
                                    </div>
                                </div>
                            </div><div class="col-sm-6 col-md-4">
                                <div class="thumbnail">
                                    <img src="image/sa3.png" alt="...">
                                    <div class="price">5.90 €</div>
                                    <div class="caption">
                                        <h4>Salade Light</h4>
                                        <p>Salade, Tomate, Concombre, Maïs et Vinaigre balsamique</p>
                                        <a href="#" class="btn btn-order" role="button"><span class="fas fa-shopping-cart"></span> Commander</a>
                                    </div>
                                </div>
                            </div><div class="col-sm-6 col-md-4">
                                <div class="thumbnail">
                                    <img src="image/sa3.png" alt="...">
                                    <div class="price">5.90 €</div>
                                    <div class="caption">
                                        <h4>Salade Light</h4>
                                        <p>Salade, Tomate, Concombre, Maïs et Vinaigre balsamique</p>
                                        <a href="#" class="btn btn-order" role="button"><span class="fas fa-shopping-cart"></span> Commander</a>
                                    </div>
                                </div>
                            </div><div class="col-sm-6 col-md-4">
                                <div class="thumbnail">
                                    <img src="image/sa3.png" alt="...">
                                    <div class="price">5.90 €</div>
                                    <div class="caption">
                                        <h4>Salade Light</h4>
                                        <p>Salade, Tomate, Concombre, Maïs et Vinaigre balsamique</p>
                                        <a href="#" class="btn btn-order" role="button"><span class="fas fa-shopping-cart"></span> Commander</a>
                                    </div>
                                </div>
                            </div><div class="col-sm-6 col-md-4">
                                <div class="thumbnail">
                                    <img src="image/sa3.png" alt="...">
                                    <div class="price">5.90 €</div>
                                    <div class="caption">
                                        <h4>Salade Light</h4>
                                        <p>Salade, Tomate, Concombre, Maïs et Vinaigre balsamique</p>
                                        <a href="#" class="btn btn-order" role="button"><span class="fas fa-shopping-cart"></span> Commander</a>
                                    </div>
                                </div>
                            </div><div class="col-sm-6 col-md-4">
                                <div class="thumbnail">
                                    <img src="image/sa3.png" alt="...">
                                    <div class="price">5.90 €</div>
                                    <div class="caption">
                                        <h4>Salade Light</h4>
                                        <p>Salade, Tomate, Concombre, Maïs et Vinaigre balsamique</p>
                                        <a href="#" class="btn btn-order" role="button"><span class="fas fa-shopping-cart"></span> Commander</a>
                                    </div>
                                </div>
                            </div><div class="col-sm-6 col-md-4">
                                <div class="thumbnail">
                                    <img src="image/sa3.png" alt="...">
                                    <div class="price">5.90 €</div>
                                    <div class="caption">
                                        <h4>Salade Light</h4>
                                        <p>Salade, Tomate, Concombre, Maïs et Vinaigre balsamique</p>
                                        <a href="#" class="btn btn-order" role="button"><span class="fas fa-shopping-cart"></span> Commander</a>
                                    </div>
                                </div>
                            </div><div class="col-sm-6 col-md-4">
                                <div class="thumbnail">
                                    <img src="image/sa3.png" alt="...">
                                    <div class="price">5.90 €</div>
                                    <div class="caption">
                                        <h4>Salade Light</h4>
                                        <p>Salade, Tomate, Concombre, Maïs et Vinaigre balsamique</p>
                                        <a href="#" class="btn btn-order" role="button"><span class="fas fa-shopping-cart"></span> Commander</a>
                                    </div>
                                </div>
                            </div><div class="col-sm-6 col-md-4">
                                <div class="thumbnail">
                                    <img src="image/sa3.png" alt="...">
                                    <div class="price">5.90 €</div>
                                    <div class="caption">
                                        <h4>Salade Light</h4>
                                        <p>Salade, Tomate, Concombre, Maïs et Vinaigre balsamique</p>
                                        <a href="#" class="btn btn-order" role="button"><span class="fas fa-shopping-cart"></span> Commander</a>
                                    </div>
                                </div>
                            </div><div class="col-sm-6 col-md-4">
                                <div class="thumbnail">
                                    <img src="image/sa3.png" alt="...">
                                    <div class="price">5.90 €</div>
                                    <div class="caption">
                                        <h4>Salade Light</h4>
                                        <p>Salade, Tomate, Concombre, Maïs et Vinaigre balsamique</p>
                                        <a href="#" class="btn btn-order" role="button"><span class="fas fa-shopping-cart"></span> Commander</a>
                                    </div>
                                </div>
                            </div><div class="col-sm-6 col-md-4">
                                <div class="thumbnail">
                                    <img src="image/sa3.png" alt="...">
                                    <div class="price">5.90 €</div>
                                    <div class="caption">
                                        <h4>Salade Light</h4>
                                        <p>Salade, Tomate, Concombre, Maïs et Vinaigre balsamique</p>
                                        <a href="#" class="btn btn-order" role="button"><span class="fas fa-shopping-cart"></span> Commander</a>
                                    </div>
                                </div>
                            </div><div class="col-sm-6 col-md-4">
                                <div class="thumbnail">
                                    <img src="image/sa3.png" alt="...">
                                    <div class="price">5.90 €</div>
                                    <div class="caption">
                                        <h4>Salade Light</h4>
                                        <p>Salade, Tomate, Concombre, Maïs et Vinaigre balsamique</p>
                                        <a href="#" class="btn btn-order" role="button"><span class="fas fa-shopping-cart"></span> Commander</a>
                                    </div>
                                </div>
                            </div><div class="col-sm-6 col-md-4">
                                <div class="thumbnail">
                                    <img src="image/s2.png" alt="...">
                                    <div class="price">3.40 €</div>
                                    <div class="caption">
                                        <h4>Onion Rings</h4>
                                        <p>Rondelles d'oignon frits</p>
                                        <a href="#" class="btn btn-order" role="button"><span class="fas fa-shopping-cart"></span> Commander</a>
                                    </div>
                                </div>
                            </div><div class="col-sm-6 col-md-4">
                                <div class="thumbnail">
                                    <img src="image/s3.png" alt="...">
                                    <div class="price">5.90 €</div>
                                    <div class="caption">
                                        <h4>Nuggets</h4>
                                        <p>Nuggets de poulet frits</p>
                                        <a href="#" class="btn btn-order" role="button"><span class="fas fa-shopping-cart"></span> Commander</a>
                                    </div>
                                </div>
                            </div><div class="col-sm-6 col-md-4">
                                <div class="thumbnail">
                                    <img src="image/s4.png" alt="...">
                                    <div class="price">3.50 €</div>
                                    <div class="caption">
                                        <h4>Nuggets Fromage</h4>
                                        <p>Nuggets de fromage frits</p>
                                        <a href="#" class="btn btn-order" role="button"><span class="fas fa-shopping-cart"></span> Commander</a>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-sm-6 col-md-4">
                                <div class="thumbnail">
                                    <img src="image/s5.png" alt="...">
                                    <div class="price">5.90 €</div>
                                    <div class="caption">
                                        <h4>Ailes de Poulet</h4>
                                        <p>Ailes de poulet Barbecue</p>
                                        <a href="#" class="btn btn-order" role="button"><span class="fas fa-shopping-cart"></span> Commander</a>
                                    </div>
                                </div>
                            </div></div>
                        </div><div class="tab-pane" id="4"><div class="row"><div class="col-sm-6 col-md-4">
                                <div class="thumbnail">
                                    <img src="image/sa1.png" alt="...">
                                    <div class="price">8.90 €</div>
                                    <div class="caption">
                                        <h4>César Poulet Pané</h4>
                                        <p>Poulet Pané, Salade, Tomate et la fameuse sauce César</p>
                                        <a href="#" class="btn btn-order" role="button"><span class="fas fa-shopping-cart"></span> Commander</a>
                                    </div>
                                </div>
                            </div><div class="col-sm-6 col-md-4">
                                <div class="thumbnail">
                                    <img src="image/sa3.png" alt="...">
                                    <div class="price">8.90 €</div>
                                    <div class="caption">
                                        <h4>César Poulet Grillé</h4>
                                        <p>Poulet Grillé, Salade, Tomate et la fameuse sauce César</p>
                                        <a href="#" class="btn btn-order" role="button"><span class="fas fa-shopping-cart"></span> Commander</a>
                                    </div>
                                </div>
                            </div><div class="col-sm-6 col-md-4">
                                <div class="thumbnail">
                                    <img src="image/sa6.png" alt="..." >
                                    <div class="price">5.90 €</div>
                                    <div class="caption">
                                        <h4>Salade Light</h4>
                                        <p>Salade, Tomate, Concombre, Maïs et Vinaigre balsamique</p>
                                        <a href="#" class="btn btn-order" role="button"><span class="fas fa-shopping-cart"></span> Commander</a>
                                    </div>
                                </div>
                            </div><div class="col-sm-6 col-md-4">
                                <div class="thumbnail">
                                    <img src="image/sa3.png" alt="...">
                                    <div class="price">5.90 €</div>
                                    <div class="caption">
                                        <h4>Salade Light</h4>
                                        <p>Salade, Tomate, Concombre, Maïs et Vinaigre balsamique</p>
                                        <a href="#" class="btn btn-order" role="button"><span class="fas fa-shopping-cart"></span> Commander</a>
                                    </div>
                                </div>
                            </div><div class="col-sm-6 col-md-4">
                                <div class="thumbnail">
                                    <img src="image/sa4.png" alt="...">
                                    <div class="price">7.90 €</div>
                                    <div class="caption">
                                        <h4>Poulet Pané</h4>
                                        <p>Poulet Pané, Salade, Tomate et la sauce de votre choix</p>
                                        <a href="#" class="btn btn-order" role="button"><span class="fas fa-shopping-cart"></span> Commander</a>
                                    </div>
                                </div>
                            </div><div class="col-sm-6 col-md-4">
                                <div class="thumbnail">
                                    <img src="image/sa5.png" alt="...">
                                    <div class="price">7.90 €</div>
                                    <div class="caption">
                                        <h4>Poulet Grillé</h4>
                                        <p>Poulet Grillé, Salade, Tomate et la sauce de votre choix</p>
                                        <a href="#" class="btn btn-order" role="button"><span class="fas fa-shopping-cart"></span> Commander</a>
                                    </div>
                                </div>
                            </div></div>
                        </div>
                        

                        <div class="tab-pane" id="5"><div class="row"><div class="col-sm-6 col-md-4">
                                <div class="thumbnail">
                                    <img src="image/bo1.png" alt="...">
                                    <div class="price">1.90 €</div>
                                    <div class="caption">
                                        <h4>Coca-Cola</h4>
                                        <p>Au choix: Petit, Moyen ou Grand</p>
                                        <a href="#" class="btn btn-order" role="button"><span class="fas fa-shopping-cart"></span> Commander</a>
                                    </div>
                                </div>
                            </div><div class="col-sm-6 col-md-4">
                                <div class="thumbnail">
                                    <img src="image/bo2.png" alt="...">
                                    <div class="price">1.90 €</div>
                                    <div class="caption">
                                        <h4>Coca-Cola Light</h4>
                                        <p>Au choix: Petit, Moyen ou Grand</p>
                                        <a href="#" class="btn btn-order" role="button"><span class="fas fa-shopping-cart"></span> Commander</a>
                                    </div>
                                </div>
                            </div><div class="col-sm-6 col-md-4">
                                <div class="thumbnail">
                                    <img src="image/bo4.png" alt="...">
                                    <div class="price">1.90 €</div>
                                    <div class="caption">
                                        <h4>Fanta</h4>
                                        <p>Au choix: Petit, Moyen ou Grand</p>
                                        <a href="#" class="btn btn-order" role="button"><span class="fas fa-shopping-cart"></span> Commander</a>
                                    </div>
                                </div>
                            </div><div class="col-sm-6 col-md-4">
                                <div class="thumbnail">
                                    <img src="image/bo5.png" alt="...">
                                    <div class="price">1.90 €</div>
                                    <div class="caption">
                                        <h4>Coca-Cola Zéro</h4>
                                        <p>Au choix: Petit, Moyen ou Grand</p>
                                        <a href="#" class="btn btn-order" role="button"><span class="fas fa-shopping-cart"></span> Commander</a>
                                    </div>
                                </div>
                            </div><div class="col-sm-6 col-md-4">
                                <div class="thumbnail">
                                    <img src="image/bo5.png" alt="...">
                                    <div class="price">1.90 €</div>
                                    <div class="caption">
                                        <h4>macdo</h4>
                                        <p>Au choix: Petit, Moyen ou Grand</p>
                                        <a href="#" class="btn btn-order" role="button"><span class="fas fa-shopping-cart"></span> Commander</a>
                                    </div>
                                </div>
                            </div><div class="col-sm-6 col-md-4">
                                <div class="thumbnail">
                                    <img src="image/bo5.png" alt="...">
                                    <div class="price">1.90 €</div>
                                    <div class="caption">
                                        <h4>Nestea</h4>
                                        <p>Au choix: Petit, Moyen ou Grand</p>
                                        <a href="#" class="btn btn-order" role="button"><span class="fas fa-shopping-cart"></span> Commander</a>
                                    </div>
                                </div>
                            </div><div class="col-sm-6 col-md-4">
                                <div class="thumbnail">
                                    <img src="image/bo5.png" alt="...">
                                    <div class="price">1.90 €</div>
                                    <div class="caption">
                                        <h4>Coca-Cola Zéro</h4>
                                        <p>Au choix: Petit, Moyen ou Grand</p>
                                        <a href="#" class="btn btn-order" role="button"><span class="fas fa-shopping-cart"></span> Commander</a>
                                    </div>
                                </div>
                            </div><div class="col-sm-6 col-md-4">
                                <div class="thumbnail">
                                    <img src="image/bo5.png" alt="...">
                                    <div class="price">1.90 €</div>
                                    <div class="caption">
                                        <h4>Coca-Cola Zéro</h4>
                                        <p>Au choix: Petit, Moyen ou Grand</p>
                                        <a href="#" class="btn btn-order" role="button"><span class="fas fa-shopping-cart"></span> Commander</a>
                                    </div>
                                </div>
                            </div><div class="col-sm-6 col-md-4">
                                <div class="thumbnail">
                                    <img src="image/bo5.png" alt="...">
                                    <div class="price">1.90 €</div>
                                    <div class="caption">
                                        <h4>Coca-Cola Zéro</h4>
                                        <p>Au choix: Petit, Moyen ou Grand</p>
                                        <a href="#" class="btn btn-order" role="button"><span class="fas fa-shopping-cart"></span> Commander</a>
                                    </div>
                                </div>
                            </div><div class="col-sm-6 col-md-4">
                                <div class="thumbnail">
                                    <img src="image/bo5.png" alt="...">
                                    <div class="price">1.90 €</div>
                                    <div class="caption">
                                        <h4>Sprite</h4>
                                        <p>Au choix: Petit, Moyen ou Grand</p>
                                        <a href="#" class="btn btn-order" role="button"><span class="fas fa-shopping-cart"></span> Commander</a>
                                    </div>
                                </div>
                            </div><div class="col-sm-6 col-md-4">
                                <div class="thumbnail">
                                    <img src="image/bo6.png" alt="...">
                                    <div class="price">1.90 €</div>
                                    <div class="caption">
                                        <h4>Nestea</h4>
                                        <p>Au choix: Petit, Moyen ou Grand</p>
                                        <a href="#" class="btn btn-order" role="button"><span class="fas fa-shopping-cart"></span> Commander</a>
                                    </div>
                                </div>
                            </div></div>
                        </div><div class="tab-pane" id="6"><div class="row"><div class="col-sm-6 col-md-4">
                                <div class="thumbnail">
                                    <img src="image/d1.png" alt="...">
                                    <div class="price">4.90 €</div>
                                    <div class="caption">
                                        <h4>Fondant au chocolat</h4>
                                        <p>Au choix: Chocolat Blanc ou au lait</p>
                                        <a href="#" class="btn btn-order" role="button"><span class="fas fa-shopping-cart"></span> Commander</a>
                                    </div>
                                </div>
                            </div><div class="col-sm-6 col-md-4">
                                <div class="thumbnail">
                                    <img src="image/d2.png" alt="...">
                                    <div class="price">2.90 €</div>
                                    <div class="caption">
                                        <h4>Muffin</h4>
                                        <p>Au choix: Au fruits ou au chocolat</p>
                                        <a href="#" class="btn btn-order" role="button"><span class="fas fa-shopping-cart"></span> Commander</a>
                                    </div>
                                </div>
                            </div><div class="col-sm-6 col-md-4">
                                <div class="thumbnail">
                                    <img src="image/k1.jpg" alt="...">
                                    <div class="price">2.90 €</div>
                                    <div class="caption">
                                        <h4 >Pomme</h4>
                                        <p>Au choix: Au fruits</p>
                                        <a href="#" class="btn btn-order" role="button"><span class="fas fa-shopping-cart"></span> Commander</a>
                                    </div>
                                </div>
                            </div><div class="col-sm-6 col-md-4">
                                <div class="thumbnail">
                                    <img src="image/k2.jpg" alt="...">
                                    <div class="price">2.90 €</div>
                                    <div class="caption">
                                        <h4>Raisin</h4>
                                        <p>Au choix: Au fruits</p>
                                        <a href="#" class="btn btn-order" role="button"><span class="fas fa-shopping-cart"></span> Commander</a>
                                    </div>
                                </div>
                            </div><div class="col-sm-6 col-md-4">
                                <div class="thumbnail">
                                    <img src="image/d2.png" alt="...">
                                    <div class="price">2.90 €</div>
                                    <div class="caption">
                                        <h4>Muffin</h4>
                                        <p>Au choix: Au fruits ou au chocolat</p>
                                        <a href="#" class="btn btn-order" role="button"><span class="fas fa-shopping-cart"></span> Commander</a>
                                    </div>
                                </div>
                            </div><div class="col-sm-6 col-md-4">
                                <div class="thumbnail">
                                    <img src="image/k3.jpg" alt="...">
                                    <div class="price">0.90 €</div>
                                    <div class="caption">
                                        <h4>Orange</h4>
                                        <p>Au choix: Au fruits ou au chocolat</p>
                                        <a href="#" class="btn btn-order" role="button"><span class="fas fa-shopping-cart"></span> Commander</a>
                                    </div>
                                </div>
                            </div><div class="col-sm-6 col-md-4">
                                <div class="thumbnail">
                                    <img src="image/d3.png" alt="...">
                                    <div class="price">2.90 €</div>
                                    <div class="caption">
                                        <h4>Beignet</h4>
                                        <p>Au choix: Au chocolat ou à la vanille</p>
                                        <a href="#" class="btn btn-order" role="button"><span class="fas fa-shopping-cart"></span> Commander</a>
                                    </div>
                                </div>
                            </div><div class="col-sm-6 col-md-4">
                                <div class="thumbnail">
                                    <img src="image/d4.png" alt="...">
                                    <div class="price">3.90 €</div>
                                    <div class="caption">
                                        <h4>Milkshake</h4>
                                        <p>Au choix: Fraise, Vanille ou Chocolat</p>
                                        <a href="#" class="btn btn-order" role="button"><span class="fas fa-shopping-cart"></span> Commander</a>
                                    </div>
                                </div>
                            </div><div class="col-sm-6 col-md-4">
                                <div class="thumbnail">
                                    <img src="image/d5.png" alt="...">
                                    <div class="price">4.90 €</div>
                                    <div class="caption">
                                        <h4>Sundae</h4>
                                        <p>Au choix: Fraise, Caramel ou Chocolat</p>
                                        <a href="#" class="btn btn-order" role="button"><span class="fas fa-shopping-cart"></span> Commander</a>
                                      </div>
                                </div>
                            </div></div>
                        </div></div></div>

    </body>
</html>