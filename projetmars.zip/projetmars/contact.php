
<!DOCTYPE html>
<html>
<head>
	<title>contact</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="js/bootstrap.min.js">
</head>
<body>
	<figure class="j51_profile j51_profile470"><img src="admin/image/restaurant.jpg" alt="Profile Image" style="padding: 50px;margin-left: 500px;"><figcaption><h3 style="color:#000000; text-align: center ">Hôtel Restaurant Le Fair Play </h3><h5 style="color:#39011a" ></h5><p style="text-align: center;">27 grand rue - 
40550 COCODY ANGRE - 
Tél. : 05 58 90 44 94</p>
<p style="text-align: center;">N’hésitez pas à contacter Le Fair Play pour tout renseignement (réservation à l’hôtel ou au restaurant, repas de groupe, soirée étape affaires…).</p>
<div class="group-form " >
	<div class="container h-100">
	<div class="d-flex justify-content-center">
			<div class=" col-md-6 animated bounceInDown myForm">

<form id="kontakt" method="POST" action="inscription.php" onsubmit="reset(); return false;">
		<br><br>
		<label for="nom">nom</label>
		<input type="nom" name="nom" id="nom" placeholder="votre nom" required="">

		<br><br>

		<label for="prenom">prenom</label>
		<input type="prenom" name="prenom" id="prenom" placeholder="votre prenom" required="">
		<br><br>
		<label for="email">email</label>
		<input type="text" name="email" id="email" placeholder="votre email" required="veuillez remplir ce champ">
		<br><br>
		<label>message</label>
		<input type="comment" name="comment" id="comment" placeholder="" required="">
		<br><br>
		<input type="submit" id="submit" class="btn btn-primary" value="envoyer" required="">
  </form>
  </div>
</div>
</div>
</div>
</figcaption>
</figure>
</body>
</html>