

<!DOCTYPE html>
<html>
<head>
	<title>RESTAURANT</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- image a mettre!--> 
	<link href="" rel="" type="image/....">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="js/bootstrap.min.js">
	<link rel="stylesheet" type="text/css" href="js/jquery.min.js">
	<link href="/templates/j51_harmony/css/animate.css" rel="stylesheet" />
	<link href="http://www.fairplay-leon.com/modules/mod_j51icons/css/style.css" rel="stylesheet" />
	<link href="http://www.fairplay-leon.com/plugins/system/fmalertcookies/assets/css/bootstrap.min.css" rel="stylesheet" />

	<link href="http://www.fairplay-leon.com/plugins/system/fmalertcookies/assets/css/custom.css" rel="stylesheet" />
  <link rel="stylesheet" type="text/css" href="css/all.min.css">
  <link rel="stylesheet" type="text/css" href="js/all.min.js">

</head>
<body>

          
	<script src="/media/jui/js/jquery.min.js?6e610058e258745b63facb405ea3a32f"></script>
	<script src="/media/jui/js/jquery-noconflict.js?6e610058e258745b63facb405ea3a32f"></script>
	<script src="/media/jui/js/jquery-migrate.min.js?6e610058e258745b63facb405ea3a32f"></script>
	<script src="/media/system/js/caption.js?6e610058e258745b63facb405ea3a32f"></script>
	<script src="/media/jui/js/bootstrap.min.js?6e610058e258745b63facb405ea3a32f"></script>
	<script src="/templates/j51_harmony/js/modernizr.custom.js"></script>
	<script src="/templates/j51_harmony/js/jquery.slicknav.js"></script>
	<script src="/templates/j51_harmony/js/jquery.sticky.js"></script>
	<script src="/templates/j51_harmony/js/scripts.js"></script>
	<script src="http://www.fairplay-leon.com/modules/mod_j51icons/js/modernizr.custom.js"></script>
	<script>
	
	<script>
jQuery(window).on('load',  function() {
				new JCaption('img.caption');
			});

            jQuery(document).ready(function() {
                jQuery('.hornavmenu .hornav').slicknav();
            });
        

    Modernizr.load({  
      test: Modernizr.touch,  
      yep : "", 
      nope: "/templates/j51_harmony/js/jquery.visible.js"  
    });


        jQuery(window).load(function(){
            jQuery(".header_row").sticky({ 
                topSpacing: 0
            });
        });
    

    jQuery(document).load(jQuery(window).bind("resize", listenWidth));

        function listenWidth( e ) {
            if(jQuery(window).width()<767)
            {
                jQuery("#sidecol_b").remove().insertAfter(jQuery("#content_remainder"));
            } else {
                jQuery("#sidecol_b").remove().insertBefore(jQuery("#content_remainder"));
            }
            if(jQuery(window).width()<767)
            {
                jQuery("#sidecol_a").remove().insertAfter(jQuery("#content_remainder"));
            } else {
                jQuery("#sidecol_a").remove().insertBefore(jQuery("#content_remainder"));
            }
        }
    
	</script>
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1"/>


<link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Source+Sans+Pro:400,500,900&subset=latin" /> 
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-102721622-1', 'auto');
  ga('send', 'pageview');

</script>
</head>
<body class="" >

		<	
		<header id="container_header" style=" background: linear-gradient(90deg, rgba(2,0,36,1) 0%, rgba(149,199,20,1) 0%, rgba(0,212,255,1) 96%);">

		<div class="header_spacer">
			<div class="header_row">

				<div class="wrapper960">
				<div class="header-2">
			            
		<div class="module ">
		<div class="module_content">
			

          
<div class="custom"  >
	<p><a href="#" target="_blank" rel="noopener noreferrer"><img src="image/facebook_blc.png" /></a></p></div>
		</div> 
		</div>
		</div>
		<div id="logo">
    
  <div class="logo logo-image"> <a href="/" title="">
  <img class="logo-image primary-logo-image" src="image/logo.png" alt="Logo" /></a>
   </div>
   
</div>
<div class="hornavmenu">
<div class="hornav">
            


     </div>
    </div>
<div class="clear"></div>
<div id="socialmedia">
<div class="hornav">        
    <nav class="navbar navbar-expand-lg">
 
    <ul class="navbar-nav">
      <li class="nav-item active">
        <a class="nav-link" href="index.php" style="color: white;margin-right: 30px; " >ACCUEIL <span class="sr-only">(current)</span></a>
      </li>
     <li class="nav-item">
        <a class="nav-link" href="#" style="color: white;   margin-right: 30px;">RESTAURANT</a>
      </li>
      
           <li class="nav-item">
        <a class="nav-link" href="admin/menu.php" style="color: white;   margin-right: 30px;">MENU & SNACKS</a>
      </li>
        <li class="nav-item">
        <a class="nav-link" href="admin/fruit.php" style="color: white;background-color: orange; border-radius: 5px;">FRUITS & CAKES</a>
      </li>
       <li class="nav-item">
        <a class="nav-link" href="admin/boisson.php" style="color: white">BOISSONS</a>
      </li>
         <li class="nav-item">
        <a class="nav-link" href="admin/flamour.php" style="color: white">GALLERY</a>
      </li>
          <li class="nav-item">
        <a class="nav-link" href="contact.php" style="color: white;margin-right:40px;background-color: orange;border-radius: 5px;">CONTACT</a>
      </li>
          
        </div>
      </li>
    </ul>
  </div>
</nav>  
         
  </ul>

</div> 
</div>
</div>
</div>


			<div id="container_showcase1_modules" class="module_block border_block" style="background: url(admin/image/21.jpg) no-repeat center;height:90vh;width: 100%; ">

    
				<div class="wrapper960">
				<div id="showcase1_modules" class="block_holder">
				<div id="wrapper_showcase-1" class="block_holder_margin">
				<div class="showcase-1 showcase-1a" style="width:100%;">
		        <div class="module text-light">
			    <div class="module_surround">
				<div class="module_content">
				

<div class="custom"  >
<div style="background-color: #000; padding: 20px; max-width: 300px;">
<h3 style="color: white;font-size: 18px;">Bienvenue au FAIR PLAY !</h3>
<p>Carte aux couleurs du sud, menus au choix, plat pris sur le pouce, le chef travaille pour vous les produits frais, avec créativité. <br /><br />
<a href="https://www.logishotels.com/fr/hotel/hotel-le-fair-play-253957" target="_blank" rel="noopener noreferrer"><img style="float: left; margin-right: 10px;" src="image/logo_logis.png" width="68" height="68" /></a>Entièrement rénové en 2016, le Fair Play dispose de 10 chambres confortables. Vous êtes à 15 mn des plages assinie.</p>
</div></div>
</div> 
</div>
</div>
</div>
<div class="clear">	
</div></div></div></div>
</div>
</header>
<div>
	<div style="background-image: url('image/index.jpg')">
</div>

<div id="container_top1_modules" class="module_block border_block">
<div class="wrapper960" style="background-position: 50% 0" data-stellar-background-ratio="0.8">
<div id="top1_modules" class="block_holder">
<div id="wrapper_top-1" class="block_holder_margin">
<div class="top-1 top-1a" style="width:100%;">
<div class="module ">
<div class="module_surround">
<div class="module_content">
				

<div class="custom"  >
	<h2 style="text-align: center;">LE FAIR PLAY<br />Hôtel – Bar – Restaurant à bassam (40)</h2>
<p style="text-align: center; max-width: 540px; margin: 0 auto 10px; font-size: 12px;"><em>Au cœur du <span class="sur_text">bourg de Léon, le Fair Play</span> vous invite</em><br/>
<em>à un moment de <span class="sur_text">convivialité</span></em>
<span class="sur_text"><em>dans un esprit sportif.</em></span></p>
<p style="text-align: center; max-width: 540px; margin: 0 auto 10px;"><br />L’établissement, spacieux et lumineux, offre plusieurs espaces : <br />
<strong style="color:black ">Bar :</strong> cocktails, bières, coupes glacées et sorbets. <br />
<strong style="color: black">Restaurant :</strong> brasserie, carte &amp; menus, repas de groupe sur demande. <br /><strong style="color: black">Hôtel :</strong> 10 chambres pour un séjour privé ou une soirée étape affaires.<br /><br />
<a href="#" target="_blank" rel="alternate noopener noreferrer"><img src="image/reserver.png " alt="" /></a></p></div><br><br>
		</div> 
		</div>
		</div>
	    </div>
	<div class="clear"></div></div></div></div></div>
		
			<div id="container_top2_modules" class="module_block border_block">
			<div class="wrapper960" style="background-position: 50% 0" data-stellar-background-ratio="0.8">
			<div id="top2_modules" class="block_holder">
			<div id="wrapper_top-2" class="block_holder_margin">
			<div class="top-2 top-2a" style="width:28%;">
		    <div class="module text-light">
			<div class="module_surround">
			<div class="module_content">
				

<div class="custom" >
	<p ><span class="titre_texte_accueil"  style="font-size:23px;">Le Fair Play</span></p>
<div class="texte_accueil">27 Grand Rue <br />40 550 BASSAM (assinie)<br /> Tél. : 05 58 90 44 94 <br />@ : <a href="mailto:le-fair-play@orange.fr" style="color: white;font-size:14px;">le-fair-play@orange.fr</a></div></div>
			</div> 
			</div>
		    </div>
	        </div>
	<div class="top-2 top-2b" style="width:72%;">
	<div class="module text-light">
	<div class="module_surround">
	<div class="module_content">
				
<div class="j51_icons j51_icons574" >

	 
		<figure class="j51_icon animate " style="float:left; text-align: center">
		<i class=" fas fa-bed"></i>
					</i>
					<h3 style="color: white"><i class=" fas fa-bed">Restaurant</i></h3>
				<p >Brasserie, carte & menus, repas de groupe sur demande.</p>
	</figure>
	 
		<figure class="j51_icon animate " style="float:left; text-align: center">
		<i class=" fas fa-hourglass" ></i>
					</i>
				<h3 style="color: white">Bar</i></h3>
				<p>Venez faire une halte au bar Le Fair Play à bassam.</p>
	</figure>
	 

</div>

<div style= "clear:both;"></div>

		</div> 
		</div>
		</div>
	    </div>
	<div class="clear">
		
	</div></div></div></div></div></div>
		
		   <div id="container_main">
			<div class="wrapper960 border_block">
				
<div id ="main" class="block_holder"><div id="content_full" class="side_margins content_full">

                                    
        
            <div class="maincontent">
            <div class="message">
            <div id="system-message-container">
	</div>

      </div>
  </div>
                <div class="item-page" itemscope itemtype="https://schema.org/Article">
	            <meta itemprop="inLanguage" content="fr-FR" />
	
		<br><br>
	</header>
	
	
	<!-- Article Image -->
	<div class="pull-right item-image"> 
		<img src="image/index.jpg" alt="" itemprop="image"/>
				
			<div class ="articleBody">
		<h2 ><img style="float: left; margin-right:10px;" src="image/times.png" width="82" height="82" /><br />OUVERT 7J/7 EN ÉTÉ</h2>
<p ><strong style="text-align:10px;">RESTAURANT </strong> <br />Le midi : du lundi au samedi de 12h00 à 13h45<br />Le soir mardi, jeudi, samedi de 19h00 à 20 h45<br />Le mercredi soir seulement pour l’hôtel<br />Fermé : le soir : lundi, vendredi, dimanche. Le dimanche toute la journée.<br /><br /><strong>BAR</strong> <br />En saison : 07h-02h. <br />Hors saison : 08h30-14h00 et 18h-22H30 en semaine (jusqu’à 02h le week-end).<br /><br /><strong>HOTEL</strong><br />Ouvert du mardi au samedi – fermé le dimanche et le lundi.<br /><a href="#" target="_blank" rel="noopener noreferrer"><img src="image/facebook.png" width="20" height="20" /> Retrouvez-nous sur Facebook</a><br /><a href="#" target="_blank" rel="alternate noopener noreferrer"><img src="image/logis.png" width="20" height="20" /> Partenaire Logis</a><br /><img src="image/pmr.png" width="20" height="20" /> Rez-de-chaussée accessible aux personnes à mobilité réduite.<br /><img src="image/no_animaux.png" width="20" height="20" /> Nos amis les chiens ne sont pas admis dans l’établissement.</p> 	
</div>
</div>
 <div class="clear">
 	
 </div></div></div>
    <div class="clear">
   
 </div>
</div>
</div></div>
</div>		
		
		
		
<div class="clearfix"></div>

		
<div id="container_base" class="module_block border_block">
<div class="wrapper960">
<div id="base1_modules" class="block_holder">
<div id="base2_modules" class="block_holder">
				
<div id="container_footermenu">
<div id="footermenu">
				 
<ul class="menu">
<li class="item-516"><a href="#" style="color: white">Mentions légales</a></li>
<li class="item-517"><a href="#" style="color: white">Partenaires | Liens</a></li>
<li class="item-518"><a href="#" style="color: white">Contact</a></li>
</ul>
<div class="clear">

</div>
</div>                
</div>
<div class="clear"></div>
<div id="container_copyright">
<div id="copyright">
<p>Copyright 2017 Hôtel Restaurant Le Fair Play - Réalisation et Hébergement Mariko SAS - Dax - <a style="color:#b0004f;" href="http://www.adiane.com" target="_blank" rel="noopener noreferrer">www.adiane.com</a></p>
</div>
<div class="clear">	
</div>
</div>
</div>
</div>
</div>
</div>	

<!-- Stellar -->
<script type="text/javascript" src="/templates/j51_harmony/js/jquery.stellar.js" charset="utf-8"></script>
<script type="text/javascript">
if (Modernizr.touch) {   
    } else {   
        jQuery(window).stellar({
		horizontalScrolling: false,
    	responsive: true
	}); 
}  
</script>

<!-- Vegas Background Slideshow -->
<script type="text/javascript" src="/templates/j51_harmony/js/jquery.vegas.js" charset="utf-8"></script>
<script type="text/javascript">
jQuery(document).ready(function() {
    jQuery('#container_header').vegas({
        delay: 5000,
        timer: faslse,
        slides: [
                    { src: 'image/vegas/slide1.jpg ' },
                    { src: 'image/restaurant_fair_play.jpg'},
                    { src: 'image/vegas/slide2.jpg'},
                    { src: 'image/vegas/slidse3.jpg'},
                    { src: 'image/vegas/restaurant_fair_play_03.jpg'},
                ]
    });
});
</script>



<!--googleoff: all--><div class="cadre_alert_cookies" id="cadre_alert_cookies" style="opacity:0.92;text-align:center; margin:0px;">
	<div class="cadre_inner_alert_cookies" style="display: inline-block;width: 100%;margin:auto;max-width:100%;background-color: #333333;border:0px solid #eeeeee; border-radius:5px">
		<div class="cadre_inner_texte_alert_cookies" style="display: inline-block;padding:10px;color: #eeeeee">
			<div class="cadre_texte pull-left">
				<div style="display: inline-block; color: #ffffff;">
<div class="pull-left">
<p>En poursuivant votre navigation sur ce site, vous acceptez l’utilisation de cookies. <span style="color: #ccc;"><a style="color: #ccc;" href="/mentions-legales.html" rel="alternate">En savoir plus</a></span></p>
</div>
</div></div>
<div class="cadre_bouton pull-left">
	<div class="pull-left  col-sm-6 btn_close" style="margin:0;text-align:center">
		<button onclick="CloseCadreAlertCookie();" style="color:#eeeeee" class="btn btn-inverse btn-small popup-modal-dismiss">OK</button></div></div></div></div></div><!--googleon: all--><script type="text/javascript">/*<![CDATA[*/var name = "fmalertcookies" + "=";var ca = document.cookie.split(";");var acceptCookie = false;for(var i=0; i<ca.length; i++) {var c = ca[i];while (c.charAt(0)==" ") c = c.substring(1);if (c.indexOf(name) == 0){ acceptCookie = true; document.getElementById("cadre_alert_cookies").style.display="none";}}var d = new Date();d.setTime(d.getTime() + (30*(24*60*60*1000)));var expires_cookie = "expires="+d.toUTCString();function CloseCadreAlertCookie(){document.getElementById('cadre_alert_cookies').style.display='none'; document.cookie='fmalertcookies=true; '+expires_cookie+'; path=/';}/*]]>*/
	</script>
</body> 
</html>